#The second NMA training
#prepared by Gemechu Fanta (PhD)

#Simple matheatical operation using pytho
a=2
b=3
c=a+b
print(c)

