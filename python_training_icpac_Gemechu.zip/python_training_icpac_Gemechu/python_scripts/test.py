a=3
b=4
c=a*b
print("The product of the two numbers is ", c)
